package com.example.sakhi_sampati

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
